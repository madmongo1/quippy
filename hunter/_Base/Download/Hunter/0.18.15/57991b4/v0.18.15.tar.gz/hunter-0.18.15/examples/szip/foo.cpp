#include <szlib.h>

int main()
{
   return 0;
}