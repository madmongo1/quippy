Compiler
--------

 * `LLVM (Clang) <https://github.com/ruslo/hunter/wiki/pkg.llvm.clang>`_ - collection of modular and reusable compiler and toolchain technologies.
