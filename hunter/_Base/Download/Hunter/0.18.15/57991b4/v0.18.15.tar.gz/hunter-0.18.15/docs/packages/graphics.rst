.. spelling::

  freetype

Graphics 2D/3D
--------------

 * `Assimp <https://github.com/ruslo/hunter/wiki/pkg.assimp>`_ - portable Open Source library to import various well-known 3D model formats in a uniform manner.
 * `freetype <https://github.com/ruslo/hunter/wiki/pkg.freetype>`_ - render freetype fonts
