#include <eos/core/Landmark.hpp>

int main() {
}
