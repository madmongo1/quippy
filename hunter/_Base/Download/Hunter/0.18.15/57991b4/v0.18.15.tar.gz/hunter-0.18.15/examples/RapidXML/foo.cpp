#include "rapidxml/rapidxml.hpp"

int main()
{
	return 0;
}

