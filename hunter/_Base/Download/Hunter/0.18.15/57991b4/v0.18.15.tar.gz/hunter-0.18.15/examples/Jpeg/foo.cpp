#include <jpeglib.h>

int main() {
}
