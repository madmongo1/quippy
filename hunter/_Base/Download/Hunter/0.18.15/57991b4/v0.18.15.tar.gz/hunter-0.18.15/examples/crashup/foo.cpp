#include <crashup/Crashup.hpp>

int main() {
}
