Testing
-------

 * `Catch <https://github.com/ruslo/hunter/wiki/pkg.catch>`_ - A modern, C++-native, header-only, framework for unit-tests, TDD and BDD C++ Automated Test Cases in Headers
 * `crashpad <https://github.com/ruslo/hunter/wiki/pkg.crashpad>`_ - crash-reporting system.
 * `glog <https://github.com/ruslo/hunter/wiki/pkg.glog>`_ - C++ implementation of the Google logging module
 * `GMock <https://github.com/ruslo/hunter/wiki/pkg.gtest>`_ - extension to Google Test for writing and using C++ mock classes.
 * `GTest <https://github.com/ruslo/hunter/wiki/pkg.gtest>`_ - Google's C++ test framework!
 * `Igloo <https://github.com/ruslo/hunter/wiki/pkg.igloo>`_ - A framework for unit testing in C++
