.. Copyright (c) 2016, Ruslan Baratov
.. All rights reserved.

Hunter user
-----------

* add more find_packages
* add toolchain-id flags
* add hunter_add_package
* custom configs
* add package
* -> CGold
