Logging
-------

 * `log4cplus <https://github.com/ruslo/hunter/wiki/pkg.log4cplus>`_ - simple to use C++ logging API providing thread-safe, flexible, and arbitrarily granular control over log management and configuration.
 * `spdlog <https://github.com/ruslo/hunter/wiki/pkg.spdlog>`_ - Super fast C++ logging library.
