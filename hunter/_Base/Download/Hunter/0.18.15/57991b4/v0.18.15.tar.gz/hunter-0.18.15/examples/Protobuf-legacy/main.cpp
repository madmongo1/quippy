#include <iostream>
#include "messages/messages.pb.h"

using namespace std;
int main(int argc, char const *argv[])
{
    hunter_example::Message m;
    cout << "Hunter example" << endl;
    return 0;
}
