#include <poly2tri/poly2tri.h>

int main() {
}
